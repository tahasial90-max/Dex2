# PHANTIX Discord Feed – Einrichtung (Schritt für Schritt)

Ablauf: **Discord-Server → Bot (`bot/`) → Feed-Worker (`worker/`) → KV → PHANTIX-Hauptworker (`integration/`)**

## Status (ehrlich)
| Teil | Status |
|---|---|
| Bot-Logik (Konfiguration, Dedupe, Retry, Payload) | 14 Unit-Tests bestanden (Python, hier ausgeführt) |
| `bot.py` mit discord.py | nur syntaktisch kompiliert. **Nie gegen Discord gelaufen**, discord.py war hier nicht installierbar |
| Feed-Worker (`worker/feed-worker.js`) | 8 Tests bestanden, aber gegen eine Fake-KV in Node, **nicht** auf Cloudflare |
| Integrationsmodul (`integration/`) | 4 Tests bestanden (Fake-KV, Fake-fetch). Nicht in den Hauptworker eingebaut |
| End-to-End (Discord → Cloudflare → PHANTIX) | **nicht getestet** |

## 0. Sofort erledigen: Secrets
Das hochgeladene ZIP enthielt eine `.env` mit einem echten `FEED_TOKEN`. Behandle ihn als verbrannt:
1. Neuen Wert erzeugen: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
2. Zwei **verschiedene** Werte erzeugen: `FEED_TOKEN` (nur Bot → Worker schreiben) und `FEED_READ_TOKEN` (nur Lesen durch PHANTIX).
3. `.env` nie hochladen, nie ins ZIP packen, nie in Chats einfügen. Das ZIP nicht weitergeben.

## 1. Discord-Bot anlegen
1. https://discord.com/developers/applications → *New Application*.
2. Reiter **Bot** → Token erzeugen/zurücksetzen und kopieren (nur in `.env`).
3. Auf derselben Seite unter *Privileged Gateway Intents* **Message Content Intent** einschalten und speichern.
4. Reiter **OAuth2 → URL Generator**: Scope `bot`; Berechtigungen **View Channels** und **Read Message History** (Permissions-Integer `66560`). Die erzeugte URL öffnen und den Bot zum Server einladen, den du dafür freigeben darfst. Der Server-Admin muss zustimmen.
5. In Discord: *Einstellungen → Erweitert → Entwicklermodus* an. Rechtsklick auf jeden freigegebenen Kanal → *Kanal-ID kopieren*.
6. Optional: Kanalrechte so setzen, dass der Bot **nur** diese Kanäle sieht (zusätzliche Absicherung).

## 2. Feed-Worker (Cloudflare)
Dein bestehender Worker `phantix-discord-feed` ist mir nicht im Quelltext bekannt. `worker/feed-worker.js` ist eine passende Referenz und **ersetzt** das Skript beim Deploy. Sichere vorher den alten Code im Dashboard (*Quick Edit*, Code kopieren).
```
cd worker
# wrangler.toml: bei id die ID deines KV-Namespace PHANTIX_DISCORD_FEED eintragen
npx wrangler secret put FEED_TOKEN        # neuer Schreib-Token
npx wrangler secret put FEED_READ_TOKEN   # neuer Lese-Token
npx wrangler deploy
```
Tests lokal: `node --test worker/feed-worker.test.mjs`
Hinweis: Cloudflare KV ist eventuell konsistent. Ein neuer Eintrag kann an anderen Standorten bis zu etwa einer Minute brauchen. Einträge laufen nach 7 Tagen ab (`FEED_TTL_SECONDS`).

## 3. Bot starten
```
cd bot
cp .env.example .env      # Windows: copy .env.example .env
# .env ausfüllen: DISCORD_BOT_TOKEN, FEED_TOKEN, ALLOWED_CHANNEL_IDS (Pflicht!)
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m unittest discover -s tests
python bot.py
```
Erwartete Log-Zeilen: `Online as <Bot>, watching N channel(s).` und `Feed worker /health -> HTTP 200`.
Der Bot startet **nicht**, wenn `ALLOWED_CHANNEL_IDS` leer ist. Das ist Absicht (vorher hätte er alle sichtbaren Kanäle weitergeleitet).

## 4. End-to-End-Test
1. Schreibe in einem freigegebenen Kanal eine Testnachricht. Im Bot-Log: `Forwarded message ...`.
2. Prüfen (nach bis zu etwa einer Minute):
```
curl -H "X-Feed-Token: <FEED_READ_TOKEN>" https://phantix-discord-feed.taahasial90.workers.dev/latest
```
Erwartet: `{"ok":true,"entry":{...deine Nachricht...}}`.
3. Fehlerbilder: `HTTP 401` im Bot-Log → Token stimmt nicht mit dem Worker-Secret überein. `Network error` wird bis zu 6-mal mit Wartezeit wiederholt. Kanal ohne Eintrag → Kanal-ID falsch oder Bot sieht den Kanal nicht.

## 5. Dauerbetrieb
Der Bot ist ein dauerhaft laufender Prozess (Gateway-Verbindung), nicht für Cloudflare Workers geeignet.
- **Eigener PC/Raspberry Pi/VPS:** `systemd`-Dienst oder `docker build -t phantix-bridge bot/ && docker run -d --restart unless-stopped --env-file bot/.env phantix-bridge`.
- **Hoster mit Secret-Store** (z. B. Fly.io, Railway, Render): Image aus `bot/Dockerfile`, Variablen im Dashboard setzen, nichts in den Code schreiben. Konditionen und Gratis-Kontingente habe ich nicht geprüft.
- Wiederverbindung zu Discord übernimmt discord.py. Bei Cloudflare-Ausfall puffert der Bot bis zu `QUEUE_SIZE` Nachrichten im Speicher (bei Neustart gehen sie verloren).

## 6. Anbindung an den PHANTIX-Hauptworker (additiv, noch nicht eingebaut)
Der Hauptworker `broad-term-eb1f` wird nicht ersetzt. So fügst du die Funktion hinzu:
1. `integration/discord-context.js` neben `worker.js` legen.
2. Zugriff: **Variante A:** im Hauptworker denselben KV-Namespace mit Binding `FEED` hinzufügen. **Variante B:** Variable `FEED_URL` und Secret `FEED_READ_TOKEN` setzen.
3. In `worker.js` vor dem Gemini-Aufruf, **nur wenn nötig** (z. B. wenn die Frage zu Events passt):
```js
import { getDiscordContext, buildContextBlock } from "./discord-context.js";
// ...
const ctx = await getDiscordContext(env, { limit: 10 });
const discordBlock = buildContextBlock(ctx.entries); // "" wenn nichts da ist oder nicht konfiguriert
// discordBlock an den bestehenden Prompt anhängen; sonst bleibt alles wie bisher.
```
4. Discord-Text ist **nicht vertrauenswürdig** (jeder im Kanal kann schreiben). Das Modul zitiert ihn als Daten. Die Prüfung der Antwort (`ok`, nur `A–Z0–9`, 2–80 Zeichen) muss bleiben.
5. Der bestehende Lua-Vertrag (`{question}` rein, `{ok, answer}` raus) muss unverändert bleiben. Das habe ich nicht gegen `worker.js` geprüft, weil ich den Quelltext nicht habe.
Tests: `node --test integration/discord-context.test.mjs`
