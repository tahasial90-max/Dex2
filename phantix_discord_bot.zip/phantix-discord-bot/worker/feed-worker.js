/**
 * phantix-discord-feed (reference implementation matching the PHANTIX Discord bot).
 *
 * Bindings / secrets (names only; values live in Cloudflare, never in this file):
 *   FEED            KV namespace PHANTIX_DISCORD_FEED
 *   FEED_TOKEN      secret, used by the Discord bot for POST /ingest
 *   FEED_READ_TOKEN secret, used by readers (PHANTIX main worker) for GET /latest and /recent
 *   FEED_TTL_SECONDS optional var, default 604800 (7 days)
 *
 * Endpoints:
 *   GET  /health   no auth, returns {ok:true} only
 *   POST /ingest   header X-Feed-Token = FEED_TOKEN, JSON body from the bot
 *   GET  /latest   header X-Feed-Token = FEED_READ_TOKEN
 *   GET  /recent?limit=1..25&channel=<name>   same auth, newest first
 *
 * KV key = "m:" + (9999999999999 - createdAtMs, 13 digits) + ":" + messageId.
 * Lexicographic order is therefore newest first, and the same message (also an edit of it)
 * always maps to the same key, so re-delivery overwrites instead of duplicating.
 */

const MAX_BODY_BYTES = 16 * 1024;
const MAX_CONTENT = 4000;
const KEY_PREFIX = "m:";
const KEY_CEILING = 9999999999999;
const DEFAULT_TTL = 7 * 24 * 3600;

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });

async function safeEqual(a, b) {
  const enc = new TextEncoder();
  const [da, db] = await Promise.all([
    crypto.subtle.digest("SHA-256", enc.encode(String(a))),
    crypto.subtle.digest("SHA-256", enc.encode(String(b))),
  ]);
  const x = new Uint8Array(da);
  const y = new Uint8Array(db);
  let diff = 0;
  for (let i = 0; i < x.length; i++) diff |= x[i] ^ y[i];
  return diff === 0;
}

async function authorized(request, secret) {
  if (!secret) return false; // a missing secret means "closed", never "open"
  const given = request.headers.get("X-Feed-Token") || "";
  return given.length > 0 && (await safeEqual(given, secret));
}

export function keyFor(createdAtMs, id) {
  return KEY_PREFIX + String(KEY_CEILING - createdAtMs).padStart(13, "0") + ":" + id;
}

function cleanString(value, max) {
  return String(value ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").slice(0, max);
}

function validate(body) {
  if (!body || typeof body !== "object") return "body must be a JSON object";
  if (typeof body.id !== "string" || !/^\d{5,25}$/.test(body.id)) return "id must be a numeric string";
  if (typeof body.content !== "string" || body.content.trim() === "") return "content must be a non-empty string";
  const created = Date.parse(body.createdAt);
  if (!Number.isFinite(created) || created < 1.4e12 || created > Date.now() + 10 * 60 * 1000) {
    return "createdAt must be an ISO timestamp (not in the future)";
  }
  return null;
}

async function ingest(request, env) {
  if (!(await authorized(request, env.FEED_TOKEN))) return json({ ok: false, error: "unauthorized" }, 401);
  const raw = await request.text();
  if (raw.length > MAX_BODY_BYTES) return json({ ok: false, error: "payload_too_large" }, 413);
  let body;
  try {
    body = JSON.parse(raw);
  } catch {
    return json({ ok: false, error: "invalid_json" }, 400);
  }
  const problem = validate(body);
  if (problem) return json({ ok: false, error: "invalid_payload", detail: problem }, 400);

  const createdMs = Date.parse(body.createdAt);
  const entry = {
    id: body.id,
    content: cleanString(body.content, MAX_CONTENT),
    channel: cleanString(body.channel, 100),
    channelId: cleanString(body.channelId, 25),
    author: cleanString(body.author, 100),
    guild: cleanString(body.guild, 100),
    url: cleanString(body.url, 200),
    createdAt: new Date(createdMs).toISOString(),
    edited: body.edited === true,
    storedAt: new Date().toISOString(),
  };
  const ttl = Math.max(60, parseInt(env.FEED_TTL_SECONDS, 10) || DEFAULT_TTL);
  await env.FEED.put(keyFor(createdMs, entry.id), JSON.stringify(entry), {
    expirationTtl: ttl,
    metadata: { ch: entry.channel },
  });
  return json({ ok: true, id: entry.id });
}

async function readRecent(env, limit, channel) {
  // With a channel filter we over-fetch keys (metadata is returned by list, no extra get needed).
  const listLimit = channel ? 200 : limit;
  const listed = await env.FEED.list({ prefix: KEY_PREFIX, limit: listLimit });
  let keys = listed.keys;
  if (channel) keys = keys.filter((k) => k.metadata && k.metadata.ch === channel);
  keys = keys.slice(0, limit);
  const values = await Promise.all(keys.map((k) => env.FEED.get(k.name)));
  const items = [];
  for (const v of values) {
    if (!v) continue;
    try {
      items.push(JSON.parse(v));
    } catch {
      /* skip corrupt entry */
    }
  }
  return items;
}

async function read(request, env, url, single) {
  if (!(await authorized(request, env.FEED_READ_TOKEN))) return json({ ok: false, error: "unauthorized" }, 401);
  let limit = 1;
  if (!single) {
    limit = parseInt(url.searchParams.get("limit") || "10", 10);
    if (!Number.isFinite(limit)) limit = 10;
    limit = Math.min(25, Math.max(1, limit));
  }
  const channel = single ? "" : cleanString(url.searchParams.get("channel") || "", 100);
  const items = await readRecent(env, limit, channel);
  if (single) return json({ ok: true, entry: items[0] || null });
  return json({ ok: true, count: items.length, entries: items });
}

export default {
  async fetch(request, env) {
    try {
      const url = new URL(request.url);
      const path = url.pathname.replace(/\/+$/, "") || "/";
      if (path === "/health" && request.method === "GET") return json({ ok: true });
      if (path === "/ingest") {
        return request.method === "POST" ? await ingest(request, env) : json({ ok: false, error: "method_not_allowed" }, 405);
      }
      if (path === "/latest" || path === "/recent") {
        return request.method === "GET"
          ? await read(request, env, url, path === "/latest")
          : json({ ok: false, error: "method_not_allowed" }, 405);
      }
      return json({ ok: false, error: "not_found" }, 404);
    } catch (err) {
      console.log("feed worker error", err && err.message);
      return json({ ok: false, error: "internal_error" }, 500);
    }
  },
};
