// Run: node --test worker/feed-worker.test.mjs   (Node 20+, no dependencies)
import test from "node:test";
import assert from "node:assert/strict";
import worker, { keyFor } from "./feed-worker.js";

class FakeKV {
  constructor() { this.m = new Map(); }
  async put(k, v, opts = {}) { this.m.set(k, { v, metadata: opts.metadata, ttl: opts.expirationTtl }); }
  async get(k) { return this.m.has(k) ? this.m.get(k).v : null; }
  async list({ prefix = "", limit = 1000 } = {}) {
    const keys = [...this.m.keys()].filter((k) => k.startsWith(prefix)).sort().slice(0, limit)
      .map((name) => ({ name, metadata: this.m.get(name).metadata }));
    return { keys };
  }
}
const mkEnv = () => ({ FEED: new FakeKV(), FEED_TOKEN: "ingest-secret", FEED_READ_TOKEN: "read-secret" });
const call = (env, path, { method = "GET", token, body } = {}) =>
  worker.fetch(new Request("https://feed.test" + path, {
    method,
    headers: { ...(token ? { "X-Feed-Token": token } : {}), "content-type": "application/json" },
    body: body === undefined ? undefined : typeof body === "string" ? body : JSON.stringify(body),
  }), env);
const msg = (id, ts, extra = {}) => ({
  id: String(id), content: "Neues Pet: Test " + id, channel: "events", channelId: "111111",
  author: "x#0", guild: "g", createdAt: new Date(ts).toISOString(), url: "", edited: false, ...extra,
});
const T = Date.now() - 60000;

test("health is public and leaks nothing", async () => {
  const r = await call(mkEnv(), "/health");
  assert.equal(r.status, 200);
  assert.deepEqual(await r.json(), { ok: true });
});
test("ingest rejects missing and wrong token, and reads need the read token", async () => {
  const env = mkEnv();
  assert.equal((await call(env, "/ingest", { method: "POST", body: msg(10000001, T) })).status, 401);
  assert.equal((await call(env, "/ingest", { method: "POST", token: "nope", body: msg(10000001, T) })).status, 401);
  assert.equal((await call(env, "/latest", { token: "ingest-secret" })).status, 401);
  assert.equal((await call(env, "/latest")).status, 401);
});
test("closed when a secret is not configured", async () => {
  const env = mkEnv(); delete env.FEED_TOKEN;
  assert.equal((await call(env, "/ingest", { method: "POST", token: "", body: msg(10000001, T) })).status, 401);
});
test("ingest stores, latest returns newest, recent is newest first", async () => {
  const env = mkEnv();
  for (const [id, off] of [[10000001, 0], [10000003, 2000], [10000002, 1000]]) {
    const r = await call(env, "/ingest", { method: "POST", token: "ingest-secret", body: msg(id, T + off) });
    assert.equal(r.status, 200);
  }
  const latest = await (await call(env, "/latest", { token: "read-secret" })).json();
  assert.equal(latest.entry.id, "10000003");
  const recent = await (await call(env, "/recent?limit=2", { token: "read-secret" })).json();
  assert.deepEqual(recent.entries.map((e) => e.id), ["10000003", "10000002"]);
});
test("duplicate delivery and edits overwrite instead of duplicating", async () => {
  const env = mkEnv();
  await call(env, "/ingest", { method: "POST", token: "ingest-secret", body: msg(10000001, T) });
  await call(env, "/ingest", { method: "POST", token: "ingest-secret", body: msg(10000001, T) });
  await call(env, "/ingest", { method: "POST", token: "ingest-secret", body: msg(10000001, T, { content: "edited text", edited: true }) });
  assert.equal(env.FEED.m.size, 1);
  const latest = await (await call(env, "/latest", { token: "read-secret" })).json();
  assert.equal(latest.entry.content, "edited text");
  assert.equal(latest.entry.edited, true);
});
test("channel filter", async () => {
  const env = mkEnv();
  await call(env, "/ingest", { method: "POST", token: "ingest-secret", body: msg(10000001, T, { channel: "events" }) });
  await call(env, "/ingest", { method: "POST", token: "ingest-secret", body: msg(10000002, T + 1000, { channel: "chat" }) });
  const r = await (await call(env, "/recent?channel=events", { token: "read-secret" })).json();
  assert.deepEqual(r.entries.map((e) => e.id), ["10000001"]);
});
test("validation: bad json, bad id, empty content, future date, oversize, wrong method", async () => {
  const env = mkEnv(); const t = "ingest-secret";
  assert.equal((await call(env, "/ingest", { method: "POST", token: t, body: "{nope" })).status, 400);
  assert.equal((await call(env, "/ingest", { method: "POST", token: t, body: msg("abc", T) })).status, 400);
  assert.equal((await call(env, "/ingest", { method: "POST", token: t, body: msg(10000001, T, { content: "  " }) })).status, 400);
  assert.equal((await call(env, "/ingest", { method: "POST", token: t, body: msg(10000001, Date.now() + 3600000) })).status, 400);
  assert.equal((await call(env, "/ingest", { method: "POST", token: t, body: msg(10000001, T, { content: "x".repeat(20000) }) })).status, 413);
  assert.equal((await call(env, "/ingest", { token: t })).status, 405);
  assert.equal((await call(env, "/nothing")).status, 404);
  assert.equal(env.FEED.m.size, 0);
});
test("ttl is applied and keys sort newest first", async () => {
  const env = mkEnv(); env.FEED_TTL_SECONDS = "3600";
  await call(env, "/ingest", { method: "POST", token: "ingest-secret", body: msg(10000001, T) });
  assert.equal([...env.FEED.m.values()][0].ttl, 3600);
  assert.ok(keyFor(2000, "1") < keyFor(1000, "1"));
});
