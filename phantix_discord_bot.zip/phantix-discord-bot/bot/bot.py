"""PHANTIX Discord Bridge.

Forwards messages from explicitly allow-listed channels of servers where this bot was invited
to the PHANTIX feed worker. No DMs, no other channels. Secrets come from the environment only.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
from datetime import timezone

import aiohttp
import discord
from dotenv import load_dotenv

from feed_logic import (
    Config, ConfigError, RedactFilter, SeenCache, build_payload, collect_text,
    dedupe_key, derive_health_url, load_config, retry_delay, should_retry,
)

MAX_ATTEMPTS = 6
LOG = logging.getLogger("phantix.bridge")


def embed_dicts(message: discord.Message) -> list:
    return [
        {
            "title": e.title,
            "description": e.description,
            "fields": [(f.name, f.value) for f in e.fields],
        }
        for e in message.embeds
    ]


class FeedBot(discord.Client):
    def __init__(self, cfg: Config) -> None:
        intents = discord.Intents.none()
        intents.guilds = True
        intents.guild_messages = True      # guild channels only, no DMs
        intents.message_content = True     # privileged: enable it in the Developer Portal
        super().__init__(intents=intents)
        self.cfg = cfg
        self.queue: asyncio.Queue = None  # created in setup_hook (needs the running loop)
        self.session: aiohttp.ClientSession = None
        self.sender_task: asyncio.Task = None
        self.seen = SeenCache(2000)
        self._announced = False

    async def setup_hook(self) -> None:
        self.queue = asyncio.Queue(maxsize=self.cfg.queue_size)
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15))
        self.sender_task = asyncio.create_task(self._sender(), name="feed-sender")

    async def close(self) -> None:
        if self.queue is not None and self.sender_task is not None:
            try:
                await asyncio.wait_for(self.queue.join(), timeout=10)
            except asyncio.TimeoutError:
                LOG.warning("Shutdown: %d queued messages were not delivered.", self.queue.qsize())
        if self.sender_task is not None:
            self.sender_task.cancel()
        if self.session is not None and not self.session.closed:
            await self.session.close()
        await super().close()

    async def on_ready(self) -> None:
        # on_ready can fire again after a reconnect; announce and health-check only once.
        if self._announced:
            return
        self._announced = True
        LOG.info("Online as %s, watching %d channel(s).", self.client_user_name(), len(self.cfg.channel_ids))
        try:
            async with self.session.get(derive_health_url(self.cfg.feed_url)) as response:
                LOG.info("Feed worker /health -> HTTP %s", response.status)
        except Exception as exc:
            LOG.warning("Feed worker /health not reachable: %s", type(exc).__name__)

    def client_user_name(self) -> str:
        return str(self.user) if self.user else "unknown"

    # ---- filtering -------------------------------------------------------------------
    def _allowed(self, message: discord.Message) -> bool:
        if message.guild is None:
            return False
        if self.cfg.guild_ids and message.guild.id not in self.cfg.guild_ids:
            return False
        channel = message.channel
        channel_id = channel.parent_id if isinstance(channel, discord.Thread) else channel.id
        if channel_id not in self.cfg.channel_ids:
            return False
        if self.user is not None and message.author.id == self.user.id:
            return False
        if (message.author.bot or message.webhook_id) and not self.cfg.forward_bots:
            return False
        return True

    # ---- events ----------------------------------------------------------------------
    async def on_message(self, message: discord.Message) -> None:
        self._enqueue(message, edited=False)

    async def on_message_edit(self, before: discord.Message, after: discord.Message) -> None:
        # Edits and late embed unfurls: only forward when the extracted text really changed.
        if collect_text(before.content, embed_dicts(before)) == collect_text(after.content, embed_dicts(after)):
            return
        self._enqueue(after, edited=True)

    def _enqueue(self, message: discord.Message, edited: bool) -> None:
        try:
            if not self._allowed(message):
                return
            text = collect_text(message.content, embed_dicts(message))
            if not text:
                return
            key = dedupe_key(message.id, text)
            if not self.seen.add(key):
                return
            channel = message.channel
            payload = build_payload(
                message_id=message.id,
                text=text,
                channel_name=getattr(channel, "name", ""),
                channel_id=channel.id,
                author=str(message.author),
                guild=message.guild.name,
                created_at_iso=message.created_at.astimezone(timezone.utc).isoformat(),
                jump_url=message.jump_url,
                edited=edited,
            )
            try:
                self.queue.put_nowait((key, payload))
            except asyncio.QueueFull:
                self.seen.discard(key)
                LOG.error("Queue full, dropped message %s.", message.id)
        except Exception:
            LOG.exception("Unexpected error while preparing a message")

    # ---- delivery --------------------------------------------------------------------
    async def _sender(self) -> None:
        while True:
            key, payload = await self.queue.get()
            try:
                delivered = await self._deliver(payload)
                if not delivered:
                    self.seen.discard(key)  # allow a later redelivery of the same message
            except asyncio.CancelledError:
                raise
            except Exception:
                LOG.exception("Unexpected delivery error for message %s", payload.get("id"))
            finally:
                self.queue.task_done()

    async def _deliver(self, payload: dict) -> bool:
        headers = {"X-Feed-Token": self.cfg.feed_token}
        for attempt in range(MAX_ATTEMPTS):
            retry_after = None
            try:
                async with self.session.post(self.cfg.feed_url, json=payload, headers=headers) as response:
                    status = response.status
                    if 200 <= status < 300:
                        LOG.info("Forwarded message %s from #%s", payload["id"], payload["channel"])
                        return True
                    if status in (401, 403):
                        LOG.error("Feed worker rejected the token (HTTP %s). Check FEED_TOKEN.", status)
                        return False
                    if not should_retry(status):
                        LOG.warning("Feed worker refused message %s (HTTP %s); not retrying.", payload["id"], status)
                        return False
                    raw = response.headers.get("Retry-After")
                    retry_after = float(raw) if raw and raw.replace(".", "", 1).isdigit() else None
                    LOG.warning("Feed worker HTTP %s (attempt %d/%d).", status, attempt + 1, MAX_ATTEMPTS)
            except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
                LOG.warning("Network error %s (attempt %d/%d).", type(exc).__name__, attempt + 1, MAX_ATTEMPTS)
            if attempt < MAX_ATTEMPTS - 1:
                await asyncio.sleep(retry_delay(attempt, retry_after))
        LOG.error("Gave up on message %s after %d attempts.", payload["id"], MAX_ATTEMPTS)
        return False


def main() -> int:
    load_dotenv()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    try:
        cfg = load_config(os.environ)
    except ConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2
    redact = RedactFilter([cfg.bot_token, cfg.feed_token])
    for handler in logging.getLogger().handlers:
        handler.addFilter(redact)
    bot = FeedBot(cfg)
    try:
        # log_handler=None: use the logging setup above. discord.py reconnects by itself.
        bot.run(cfg.bot_token, log_handler=None)
    except discord.LoginFailure:
        print("Discord rejected DISCORD_BOT_TOKEN (invalid or reset).", file=sys.stderr)
        return 3
    except discord.PrivilegedIntentsRequired:
        print("Enable 'Message Content Intent' in the Discord Developer Portal (Bot tab).", file=sys.stderr)
        return 4
    return 0


if __name__ == "__main__":
    sys.exit(main())
