import logging
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import feed_logic as fl  # noqa: E402

GOOD = {
    "DISCORD_BOT_TOKEN": "not-a-real-token",
    "FEED_URL": "https://feed.example.workers.dev/ingest",
    "FEED_TOKEN": "feed-secret",
    "ALLOWED_CHANNEL_IDS": "123, 456",
}


class ConfigTests(unittest.TestCase):
    def test_ok(self):
        cfg = fl.load_config(GOOD)
        self.assertEqual(cfg.channel_ids, frozenset({123, 456}))
        self.assertFalse(cfg.forward_bots)

    def test_empty_allowlist_fails_closed(self):
        with self.assertRaises(fl.ConfigError):
            fl.load_config({**GOOD, "ALLOWED_CHANNEL_IDS": ""})

    def test_invalid_id_is_error_not_dropped(self):
        with self.assertRaises(fl.ConfigError):
            fl.load_config({**GOOD, "ALLOWED_CHANNEL_IDS": "123,abc"})

    def test_placeholders_and_missing(self):
        for key, value in (("DISCORD_BOT_TOKEN", "PASTE_YOUR_TOKEN"), ("FEED_TOKEN", ""), ("FEED_URL", "http://evil.example/ingest")):
            with self.assertRaises(fl.ConfigError, msg=key):
                fl.load_config({**GOOD, key: value})

    def test_localhost_http_allowed(self):
        fl.load_config({**GOOD, "FEED_URL": "http://localhost:8787/ingest"})

    def test_health_url(self):
        self.assertEqual(fl.derive_health_url(GOOD["FEED_URL"]), "https://feed.example.workers.dev/health")


class PayloadTests(unittest.TestCase):
    def test_collect_text_with_embeds(self):
        text = fl.collect_text(" hi ", [{"title": "T", "description": "D", "fields": [("n", "v")]}])
        self.assertEqual(text, "hi\nT\nD\nn: v")

    def test_collect_text_empty(self):
        self.assertEqual(fl.collect_text("", []), "")

    def test_collect_text_is_capped(self):
        self.assertEqual(len(fl.collect_text("x" * 9000, [])), fl.MAX_CONTENT_CHARS)

    def test_payload_shape(self):
        p = fl.build_payload(message_id=5, text="t", channel_name="", channel_id=9, author="a", guild="g",
                             created_at_iso="2026-01-01T00:00:00+00:00", jump_url="u", edited=False)
        self.assertEqual(p["id"], "5")
        self.assertEqual(p["channel"], "9")


class DedupeAndRetryTests(unittest.TestCase):
    def test_seen_cache(self):
        c = fl.SeenCache(2)
        self.assertTrue(c.add("a"))
        self.assertFalse(c.add("a"))
        c.add("b"); c.add("c")
        self.assertTrue(c.add("a"))  # evicted, new again
        c.discard("a")
        self.assertTrue(c.add("a"))

    def test_edit_with_new_text_is_not_duplicate(self):
        self.assertNotEqual(fl.dedupe_key(1, "a"), fl.dedupe_key(1, "b"))
        self.assertEqual(fl.dedupe_key(1, "a"), fl.dedupe_key(1, "a"))

    def test_retry_policy(self):
        self.assertTrue(fl.should_retry(429) and fl.should_retry(503))
        self.assertFalse(fl.should_retry(400) or fl.should_retry(401) or fl.should_retry(413))
        zero = lambda: 0.0
        self.assertEqual(fl.retry_delay(0, rng=zero), 1.0)
        self.assertEqual(fl.retry_delay(10, rng=zero), 60.0)
        self.assertEqual(fl.retry_delay(0, retry_after=30, rng=zero), 30.0)
        self.assertEqual(fl.retry_delay(0, retry_after=9999, rng=zero), 120.0)


class RedactTests(unittest.TestCase):
    def test_secret_removed(self):
        rec = logging.LogRecord("x", logging.INFO, "", 0, "token=%s end", ("feed-secret",), None)
        fl.RedactFilter(["feed-secret"]).filter(rec)
        self.assertNotIn("feed-secret", rec.getMessage())


if __name__ == "__main__":
    unittest.main()
