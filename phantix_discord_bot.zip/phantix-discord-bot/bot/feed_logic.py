"""Pure helpers for the PHANTIX Discord bridge. Stdlib only, so they can be tested without discord.py."""
from __future__ import annotations

import hashlib
import logging
import random
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Optional
from urllib.parse import urlparse

MAX_CONTENT_CHARS = 4000
MAX_EMBEDS = 3
MAX_EMBED_FIELDS = 8


class ConfigError(Exception):
    pass


@dataclass(frozen=True)
class Config:
    bot_token: str
    feed_url: str
    feed_token: str
    channel_ids: frozenset
    guild_ids: frozenset
    forward_bots: bool
    queue_size: int


def _is_placeholder(value: str) -> bool:
    return value.upper().startswith(("PASTE", "YOUR_", "CHANGE", "<"))


def parse_id_list(raw: str, name: str) -> frozenset:
    """Parse comma separated Discord IDs. Invalid entries raise instead of being dropped silently."""
    ids = set()
    for part in (raw or "").split(","):
        part = part.strip()
        if not part:
            continue
        if not part.isdigit():
            raise ConfigError(f"{name}: '{part}' is not a numeric Discord ID.")
        ids.add(int(part))
    return frozenset(ids)


def parse_bool(raw: str, default: bool = False) -> bool:
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def load_config(env: Mapping[str, str]) -> Config:
    bot_token = env.get("DISCORD_BOT_TOKEN", "").strip()
    feed_url = env.get("FEED_URL", "").strip()
    feed_token = env.get("FEED_TOKEN", "").strip()
    if not bot_token or _is_placeholder(bot_token):
        raise ConfigError("DISCORD_BOT_TOKEN is missing or still a placeholder.")
    if not feed_token or _is_placeholder(feed_token):
        raise ConfigError("FEED_TOKEN is missing or still a placeholder.")
    parsed = urlparse(feed_url)
    local = parsed.hostname in ("localhost", "127.0.0.1")
    if parsed.scheme != "https" and not (parsed.scheme == "http" and local):
        raise ConfigError("FEED_URL must be an https URL (http only for localhost).")
    if not parsed.hostname:
        raise ConfigError("FEED_URL has no host.")
    channel_ids = parse_id_list(env.get("ALLOWED_CHANNEL_IDS", ""), "ALLOWED_CHANNEL_IDS")
    if not channel_ids:
        # Fail closed: without an explicit allow-list the bot must not forward anything.
        raise ConfigError("ALLOWED_CHANNEL_IDS is empty. List every channel you are allowed to forward.")
    guild_ids = parse_id_list(env.get("ALLOWED_GUILD_IDS", ""), "ALLOWED_GUILD_IDS")
    try:
        queue_size = int(env.get("QUEUE_SIZE", "500"))
    except ValueError:
        raise ConfigError("QUEUE_SIZE must be an integer.")
    if not 10 <= queue_size <= 10000:
        raise ConfigError("QUEUE_SIZE must be between 10 and 10000.")
    return Config(
        bot_token=bot_token,
        feed_url=feed_url,
        feed_token=feed_token,
        channel_ids=channel_ids,
        guild_ids=guild_ids,
        forward_bots=parse_bool(env.get("FORWARD_BOT_MESSAGES"), False),
        queue_size=queue_size,
    )


def derive_health_url(feed_url: str) -> str:
    parsed = urlparse(feed_url)
    return f"{parsed.scheme}://{parsed.netloc}/health"


def collect_text(content: Optional[str], embeds: Iterable[Mapping[str, Any]]) -> str:
    """Message text plus the text of the first embeds (announcement bots often use embeds only)."""
    parts = [(content or "").strip()]
    for embed in list(embeds)[:MAX_EMBEDS]:
        title = embed.get("title")
        description = embed.get("description")
        if title:
            parts.append(str(title))
        if description:
            parts.append(str(description))
        for name, value in list(embed.get("fields") or [])[:MAX_EMBED_FIELDS]:
            parts.append(f"{name}: {value}")
    return "\n".join(p for p in parts if p).strip()[:MAX_CONTENT_CHARS]


def build_payload(*, message_id: int, text: str, channel_name: str, channel_id: int,
                  author: str, guild: str, created_at_iso: str, jump_url: str,
                  edited: bool) -> dict:
    return {
        "id": str(message_id),
        "content": text[:MAX_CONTENT_CHARS],
        "channel": (channel_name or str(channel_id))[:100],
        "channelId": str(channel_id),
        "author": author[:100],
        "guild": guild[:100],
        "createdAt": created_at_iso,
        "url": jump_url[:200],
        "edited": bool(edited),
    }


def dedupe_key(message_id: int, text: str) -> str:
    """Same message and same text is a duplicate; an edit with new text is not."""
    return f"{message_id}:{hashlib.sha1(text.encode('utf-8')).hexdigest()[:12]}"


class SeenCache:
    """Bounded memory of recently forwarded keys."""

    def __init__(self, maxlen: int = 2000) -> None:
        self._maxlen = maxlen
        self._items: "OrderedDict[str, None]" = OrderedDict()

    def add(self, key: str) -> bool:
        """Return True if the key is new, False if it was already seen."""
        if key in self._items:
            self._items.move_to_end(key)
            return False
        self._items[key] = None
        while len(self._items) > self._maxlen:
            self._items.popitem(last=False)
        return True

    def discard(self, key: str) -> None:
        self._items.pop(key, None)


def should_retry(status: int) -> bool:
    return status == 429 or status >= 500


def retry_delay(attempt: int, retry_after: Optional[float] = None, rng=random.random) -> float:
    """Exponential backoff with jitter, capped; honours Retry-After up to 120 s."""
    delay = min(60.0, 2.0 ** attempt) + rng()
    if retry_after is not None and retry_after > 0:
        delay = max(delay, min(float(retry_after), 120.0))
    return delay


class RedactFilter(logging.Filter):
    """Removes secret values from any log record (defence in depth; secrets are never logged on purpose)."""

    def __init__(self, secrets: Iterable[str]) -> None:
        super().__init__()
        self._secrets = [s for s in secrets if s]

    def filter(self, record: logging.LogRecord) -> bool:
        text = record.getMessage()
        for secret in self._secrets:
            if secret in text:
                text = text.replace(secret, "***")
        record.msg = text
        record.args = ()
        return True
